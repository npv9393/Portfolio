﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class ChangeScreen : MonoBehaviour {

    public string nextSceneName;
    private GameObject player;

	// Use this for initialization
	void Start ()
    {
        player = GameObject.Find("Ship");
    }
	
	// Update is called once per frame
	void Update ()
    {
        // changes from the title screen to the instructions
        if (SceneManager.GetActiveScene() == SceneManager.GetSceneByName("Title Screen"))
        {
            if (Input.GetKeyDown(KeyCode.Return))
            {
                nextSceneName = "Instructions";
                SceneManager.LoadScene(nextSceneName);
            }
        }

        // changes from the instructions to the game
        if (SceneManager.GetActiveScene() == SceneManager.GetSceneByName("Instructions"))
        {
            if (Input.GetKeyDown(KeyCode.Return))
            {
                nextSceneName = "Game";
                SceneManager.LoadScene(nextSceneName);
            }
        }

        // changes from the game to the game over screen
        if (SceneManager.GetActiveScene() == SceneManager.GetSceneByName("Game") && player.GetComponent<PlayerDestroy>().lives <= 0)
        {
            nextSceneName = "Game Over";
            SceneManager.LoadScene(nextSceneName);
        }

        // changes from the gameover screen to either the game or title screen
        if (SceneManager.GetActiveScene() == SceneManager.GetSceneByName("Game Over"))
        {
            if (Input.GetKeyDown(KeyCode.LeftShift) || Input.GetKeyDown(KeyCode.RightShift))
            {
                nextSceneName = "Title Screen";
                SceneManager.LoadScene(nextSceneName);
            }
            if (Input.GetKeyDown(KeyCode.Return))
            {
                nextSceneName = "Game";
                SceneManager.LoadScene(nextSceneName);
            }
        }
    }
}
