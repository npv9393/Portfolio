﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemyshoot : MonoBehaviour {

    public GameObject player;
    private Vector3 bulletVector;
    public float bulletSpeed;
    public Rigidbody2D bullet;
    public float shootCooldown;
    private float shootTimer;
    private float targetRotation;
    public GameObject projectileLauncher;
    public List<Rigidbody2D> bulletList;

	// Use this for initialization
	void Start () {
        player = GameObject.Find("Ship");
        shootTimer = shootCooldown;
        bulletList = new List<Rigidbody2D>();
	}
	
	// Update is called once per frame
	void Update ()
    {        
        TargetPlayer();

        Debug.Log(transform.rotation);

        Shoot();
        Debug.DrawLine(transform.position, player.transform.position);
	}

    /// <summary>
    /// Targets the player and positions the projectile launcher to fire at them 
    /// </summary>
    void TargetPlayer()
    {
        bulletVector = player.transform.position - projectileLauncher.transform.position;

        targetRotation = Mathf.Atan2(bulletVector.y, bulletVector.x) * Mathf.Rad2Deg;

        transform.rotation = Quaternion.Euler(0, 0, targetRotation - 90);
    }


    /// <summary>
    /// Shoots the bullet using the target vector
    /// </summary>
    void Shoot()
    {
        if (shootTimer > 0.0f)
        {
            shootTimer -= Time.deltaTime;
        }
        if(shootTimer <= 0.0f)
        {
            shootTimer = 0.0f;

            Rigidbody2D enemyBullet;
            enemyBullet = Instantiate(bullet, projectileLauncher.transform.position, Quaternion.identity) as Rigidbody2D;
            bulletList.Add(enemyBullet);
            enemyBullet.AddForce(projectileLauncher.transform.up * bulletSpeed);
            shootTimer = shootCooldown;
        }

    }
}
