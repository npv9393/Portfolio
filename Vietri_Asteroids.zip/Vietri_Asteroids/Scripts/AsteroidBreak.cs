﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AsteroidBreak : MonoBehaviour {

    public GameObject asteroid1;
    public GameObject asteroid2;
    private Vector3 minimumSize;
    private Camera screen;
    private GameObject asteroidManager;
    private AsteroidSpawn spawnScript;
    public int score;
    public GameObject gameManager;
    public Score scoreScript;
    public GameObject playerBullet;
    public bool asteroidHit;
    private Vector3 asteroidDirection;
    private float angleChange;
    private Random random;

    // Use this for initialization
    void Start ()
    {
        asteroidHit = false;
        gameManager = GameObject.Find("Game Manager");
        scoreScript = gameManager.GetComponent<Score>();
        screen = Camera.main;
        minimumSize = new Vector3(0.25f, 0.25f, 1);
        asteroidManager = GameObject.Find("Asteroid Manager");
        spawnScript = asteroidManager.GetComponent<AsteroidSpawn>();
        Vector3 asteroidDirection = gameObject.GetComponent<AsteroidMove>().velocity;
    }
	
	// Update is called once per frame
	void Update ()
    {
        if (asteroidHit)
        {
            AsteroidShot();
        }
	}

    void AsteroidShot()
    {
        // check asteroid level to add score
        switch (gameObject.GetComponent<AsteroidMove>().asteroidLevel)
        {
            case 1:
                scoreScript.asteroidScore = 20;
                break;

            case 2:
                scoreScript.asteroidScore = 50;
                break;

            case 3:
                scoreScript.asteroidScore = 100;
                break;
        }


        // test if collided with player bullet and if it is the minimum size
        if (gameObject.transform.localScale.magnitude > minimumSize.magnitude)
        {
            Vector3 screenPos = transform.position;

            Vector3 scalar = new Vector3((gameObject.transform.localScale.x) / 2, (gameObject.transform.localScale.y) / 2, 1);


            spawnScript.asteroidList.Remove(gameObject);

            // spawns 2 new asteroids and gives them vector components based on the original asteroid

            GameObject smallAsteroid1 = Instantiate(asteroid1, screenPos, Quaternion.identity);
            GameObject smallAsteroid2 = Instantiate(asteroid2, screenPos, Quaternion.identity);

            smallAsteroid1.GetComponent<AsteroidMove>().velocity = (asteroidDirection * Random.Range(1.0f, 1.5f));
            smallAsteroid2.GetComponent<AsteroidMove>().velocity = (asteroidDirection * Random.Range(1.0f, 1.5f));

            smallAsteroid1.transform.localScale = scalar;
            smallAsteroid1.GetComponent<AsteroidMove>().asteroidLevel++;

            spawnScript.asteroidList.Add(smallAsteroid1);

            smallAsteroid2.transform.localScale = scalar;
            smallAsteroid2.GetComponent<AsteroidMove>().asteroidLevel++;
            spawnScript.asteroidList.Add(smallAsteroid2);

            Destroy(gameObject);

        }

        // tests if the asteroids are the minimum size
        if (gameObject.transform.localScale.magnitude <= minimumSize.magnitude)
        {
            gameObject.GetComponent<AsteroidMove>().asteroidLevel++;

            spawnScript.asteroidList.Remove(gameObject);

            Destroy(gameObject);
        }
    }

}
