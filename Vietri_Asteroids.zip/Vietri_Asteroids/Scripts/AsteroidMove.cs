﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AsteroidMove : MonoBehaviour {

    // modifiable variables for the asteroid
    public Vector3 asteroidPosition;
    public Vector3 velocity;
    public float maxSpeed;
    private Camera gameView;
    private float viewWidth;
    private float viewHeight;
    public int asteroidLevel;

    // Use this for initialization
    void Start () {
        gameView = Camera.main;
        float randomX = Random.Range(-0.05f, 0.05f);
        float randomY = Random.Range(-0.05f, 0.05f);
        velocity = new Vector3(randomX, randomY, 0);
        viewHeight = gameView.orthographicSize * 2.0f;
        viewWidth = viewHeight * gameView.aspect;
    }
	
	// Update is called once per frame
	void Update () {

        asteroidPosition = transform.position;

        MoveAsteroid();

        WrapScreen();
	}

    /// <summary>
    /// Moves the asteroid based on its position and randomized velocity
    /// </summary>
    void MoveAsteroid()
    {
        velocity = Vector3.ClampMagnitude(velocity, maxSpeed);

        // add velocity to position
        asteroidPosition += velocity;

        transform.position = asteroidPosition;
    }

    // wraps the asteroids around the screen
    void WrapScreen()
    {
        asteroidPosition = transform.position;

        // goes off left
        if (asteroidPosition.x < -(viewWidth / 2.0f))
        {
            asteroidPosition.x = asteroidPosition.x + viewWidth;
        }

        // goes off right
        if (asteroidPosition.x > (viewWidth / 2.0f))
        {
            asteroidPosition.x = asteroidPosition.x - viewWidth;
        }

        // goes off top
        if (asteroidPosition.y > (viewHeight / 2.0f))
        {
            asteroidPosition.y = asteroidPosition.y - viewHeight;
        }

        // goes off bottom
        if (asteroidPosition.y < -(viewHeight / 2.0f))
        {
            asteroidPosition.y = asteroidPosition.y + viewHeight;
        }

        transform.position = asteroidPosition;
    }

}
