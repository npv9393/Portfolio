﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyMove : MonoBehaviour {

    public Vector3 enemyPosition;
    private Camera gameView;
    private float viewWidth;
    private float viewHeight;
    private Vector3 velocity;
    public float maxSpeed;
    public float enemySpeed;

    // Use this for initialization
    void Start () {
        gameView = Camera.main;
        velocity = new Vector3(enemySpeed, 0, 0);
        viewHeight = gameView.orthographicSize * 2.0f;
        viewWidth = viewHeight * gameView.aspect;
    }
	
	// Update is called once per frame
	void Update () {

        enemyPosition = transform.position;

        MoveEnemy();

        WrapScreen();
	}

    void MoveEnemy()
    {
        velocity = Vector3.ClampMagnitude(velocity, maxSpeed);

        // add velocity to position
        enemyPosition += velocity;

        transform.position = enemyPosition;
    }

    // wraps the enemy around the screen
    void WrapScreen()
    {
        enemyPosition = transform.position;

        // goes off left
        if (enemyPosition.x < -(viewWidth / 2.0f))
        {
            enemyPosition.x = enemyPosition.x + viewWidth;
        }

        // goes off right
        if (enemyPosition.x > (viewWidth / 2.0f))
        {
            enemyPosition.x = enemyPosition.x - viewWidth;
        }

        // goes off top
        if (enemyPosition.y > (viewHeight / 2.0f))
        {
            enemyPosition.y = enemyPosition.y - viewHeight;
        }

        // goes off bottom
        if (enemyPosition.y < -(viewHeight / 2.0f))
        {
            enemyPosition.y = enemyPosition.y + viewHeight;
        }

        transform.position = enemyPosition;
    }
}
