﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerShoot : MonoBehaviour {

    public Rigidbody2D bullet;
    public float bulletSpeed;
    public GameObject player;
    public float shotTime;
    private float shotTimer;
    private bool ableToShoot;

	// Use this for initialization
	void Start () {
        ableToShoot = true;
	}
	
	// Update is called once per frame
	void Update () {
        VehicleShoot();
	}

    // shoots a projectile from the ship
    void VehicleShoot()
    {
        if (Input.GetKeyDown(KeyCode.Space) && ableToShoot)
        {
            Rigidbody2D playerBullet;
            playerBullet = Instantiate(bullet, player.transform.position, player.transform.rotation) as Rigidbody2D;
            playerBullet.AddForce(player.transform.up * bulletSpeed);
            ableToShoot = false;
        }

        if (shotTimer > 0.0f)
        {
            shotTimer -= Time.deltaTime;
        }

        if (shotTimer <= 0.0f)
        {
            shotTimer = 0.0f;
            ableToShoot = true;
            shotTimer = shotTime;
        }

    }
}
