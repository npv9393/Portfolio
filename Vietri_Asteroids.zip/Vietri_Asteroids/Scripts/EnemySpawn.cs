﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemySpawn : MonoBehaviour {

    private Camera gameView;
    private float viewWidth;
    private float viewHeight;
    public float spawnRate;
    private float spawnTimer;
    public GameObject enemy;
    private Vector3 enemyLocation;
    public List<GameObject> enemyList;

    // Use this for initialization
    void Start () {
        gameView = Camera.main;
        viewHeight = gameView.orthographicSize * 2.0f;
        viewWidth = viewHeight * gameView.aspect;
        spawnTimer = spawnRate;
        enemyLocation = gameView.ScreenToWorldPoint(new Vector3(0, 300, 10)); // sets enemy spawn
        enemyList = new List<GameObject>();
    }
	
	// Update is called once per frame
	void Update () {
        Spawn();
	}

    /// <summary>
    /// sets the enemies to spawn on the edge in halfway up the screen
    /// </summary>
    void Spawn()
    {        
        if(spawnTimer > 0.0f)
        {
            spawnTimer -= Time.deltaTime;
        }
        if(spawnTimer <= 0.0f)
        {
            GameObject newEnemy;
            spawnTimer = 0.0f;
            newEnemy = Instantiate(enemy, enemyLocation, Quaternion.identity);
            enemyList.Add(newEnemy);
            spawnTimer = spawnRate;
        }
    }
}
