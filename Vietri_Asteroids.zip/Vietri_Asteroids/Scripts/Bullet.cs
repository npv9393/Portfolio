﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bullet : MonoBehaviour
{
    public GameObject asteroidManager;
    public AsteroidSpawn asteroidSpawnScript;
    public List<GameObject> asteroids;
    public GameObject gameManager;
    public EnemySpawn enemySpawnScript;
    public List<GameObject> enemyList;
    public float bulletDistance;

    // Use this for initialization
    void Start ()
    {
        asteroidManager = GameObject.Find("Asteroid Manager");
        asteroidSpawnScript = asteroidManager.GetComponent<AsteroidSpawn>();
        asteroids = asteroidSpawnScript.asteroidList;

        gameManager = GameObject.Find("Game Manager");
        enemySpawnScript = gameManager.GetComponent<EnemySpawn>();
        enemyList = enemySpawnScript.enemyList;

        // destroys the bullet if it hasnt collided with anything after 2 seconds
        Destroy(gameObject, 4.0f);
    }
	
	// Update is called once per frame
	void Update ()
    {
        asteroids = asteroidSpawnScript.asteroidList;
        BulletCollided();
    }

    /// <summary>
    /// tests each bullet against every asteroid in the list
    /// </summary>
    void BulletCollided()
    {
        // player bullet colliding with the asteroids
        if(gameObject.name == "Player Bullet(Clone)")
        {
            for(int i = 0; i < asteroids.Count; i++)
            {
                bulletDistance = Mathf.Sqrt(Mathf.Pow((gameObject.transform.position.x - asteroids[i].transform.position.x), 2) + Mathf.Pow((gameObject.transform.position.y - asteroids[i].transform.position.y), 2));
                float bulletSphere = gameObject.GetComponent<SpriteRenderer>().bounds.extents.magnitude;
                float asteroidSphere = asteroids[i].GetComponent<SpriteRenderer>().bounds.extents.magnitude; 

                if (bulletDistance < bulletSphere + asteroidSphere)
                {
                    Destroy(gameObject);
                    asteroids[i].GetComponent<AsteroidBreak>().asteroidHit = true;
                }
            }

            // tests if player hit enemy
            for (int i = 0; i < enemyList.Count; i++)
            {
                bulletDistance = Mathf.Sqrt(Mathf.Pow((gameObject.transform.position.x - enemyList[i].transform.position.x), 2) + Mathf.Pow((gameObject.transform.position.y - enemyList[i].transform.position.y), 2));
                float bulletSphere = gameObject.GetComponent<SpriteRenderer>().bounds.extents.magnitude;
                float enemyListSphere = enemyList[i].GetComponent<SpriteRenderer>().bounds.extents.magnitude;

                if (bulletDistance < bulletSphere + enemyListSphere)
                {
                    Destroy(gameObject);
                    Destroy(enemyList[i]);
                    enemyList.RemoveAt(i);
                    enemySpawnScript.enemyList = enemyList;
                }
            }
        }           
    }

}
