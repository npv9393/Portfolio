﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AsteroidSpawn : MonoBehaviour {

    public List<GameObject> asteroidList;
    public GameObject asteroid1;
    public GameObject asteroid2;
    public GameObject ship;
    private int randomFloat;
    private Camera gameView;
    private float viewWidth;
    private float viewHeight;
    public int round;
    private bool roundStart;
    private Vector3 spawnArea1;
    private Vector3 spawnArea2;
    private Vector3 spawnArea3;
    private Vector3 spawnArea4;

    // Use this for initialization
    void Start ()
    { 
        gameView = Camera.main;
        viewHeight = gameView.orthographicSize * 2.0f;
        viewWidth = viewHeight * gameView.aspect;
        round = 1;
        roundStart = true;

        Debug.Log("width: "+ viewWidth);
        Debug.Log("height: "+ viewHeight);

        // sets spawn areas to the edges of the screen
        spawnArea1 = gameView.ScreenToWorldPoint(new Vector3(100, 100, 10));
        spawnArea2 = gameView.ScreenToWorldPoint(new Vector3(viewWidth-100, 100, 10));
        spawnArea3 = gameView.ScreenToWorldPoint(new Vector3(viewWidth-100, viewHeight-100, 10));
        spawnArea4 = gameView.ScreenToWorldPoint(new Vector3(100, viewHeight-100, 10));

        Debug.Log(spawnArea1);
        Debug.Log(spawnArea2);
        Debug.Log(spawnArea3);
        Debug.Log(spawnArea4);
    }
	
	// Update is called once per frame
	void Update ()
    {
        if (roundStart)
        {
            roundStart = false;
            for (int i = 0; i < round + 1; i++)
            {
                SpawnAsteroids();                
            }
        }

        CheckRound();
	}


    /// <summary>
    ///  Picks a random asteroid
    /// </summary>
    /// <returns></returns>
    GameObject RandomAsteroid()
    {
        randomFloat = Random.Range(0, 2);

        if (randomFloat % 2 == 0)
        {
            return asteroid1;
        }
        else
        {
            return asteroid2;
        }
    }

    /// <summary>
    /// Generates a random position on the screen that is not on the player, or off screen
    /// </summary>
    /// <returns></returns>
    Vector3 RandomPosition()
    {

        Vector3 position;
        int randomSpawn = Random.Range(1, 5);

        switch (randomSpawn)
        {
            case 1:
                position = spawnArea1;
                return position;                

            case 2:
                position = spawnArea2;
                return position;               

            case 3:
                position = spawnArea3;
                return position;                

            case 4:
                position = spawnArea4;
                return position;

            default: position = spawnArea1;
                return position;
        }

    }

    /// <summary>
    /// Spawns the asteroids randomly around the screen
    /// </summary>
    void SpawnAsteroids()
    {
        GameObject asteroid;
        asteroid= Instantiate(RandomAsteroid(), RandomPosition(), Quaternion.identity);
        asteroidList.Add(asteroid);
        asteroid.GetComponent<AsteroidMove>().asteroidLevel = 1;
        Debug.Log("Asteroid position: " + asteroid.transform.position);
    }


    // checks the number of asteroids remaining in the round 
    void CheckRound()
    {
        if(asteroidList.Count == 0)
        {
            round++;
            roundStart = true;
        }
    }


}
