﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Vehicle : MonoBehaviour
{

    // publicly modifiable variables for the ship
    public float maxSpeed;
    public float angleOfRotation;
    public Vector3 vehiclePosition;
    public Vector3 direction;
    public Vector3 velocity;
    public Vector3 acceleration;
    public float accelerationRate;
    public Camera gameView;
    private float viewWidth;
    private float viewHeight;

    // Use this for initialization
    void Start ()
    {
        viewHeight = gameView.orthographicSize * 2.0f;
        viewWidth = viewHeight * gameView.aspect;
    }
	
	// Update is called once per frame
	void Update ()
    {
        RotateVehicle();

        Drive();

        MoveVehicle();

        WrapScreen();
    }

    // rotates the vehicle
    void RotateVehicle()
    {
        // rotation
        if (Input.GetKey(KeyCode.LeftArrow))       // left
        {
            angleOfRotation += 2;
            // rotate vector
            direction = Quaternion.Euler(0, 0, 2) * direction;
        }
        else if(Input.GetKey(KeyCode.RightArrow))       // right
        {
            angleOfRotation += -2;
            direction = Quaternion.Euler(0, 0, -2) * direction;
        }
        
        
        transform.rotation = Quaternion.Euler(0, 0, angleOfRotation);

    }


    // set direction of player
    void Drive()
    {
        if (Input.GetKey(KeyCode.UpArrow))
        {
            // acceleration
            acceleration = direction * accelerationRate;

            // calc velocity
            velocity += acceleration;

            velocity = Vector3.ClampMagnitude(velocity, maxSpeed);

            // add velocity to position
            vehiclePosition += velocity;
        }

        // condition for not accelerating
        else
        {
            // checks if the user has any veloctity over 0.01 (close to none) and slows them
            if(velocity.magnitude > 0.01)
            {
                acceleration = acceleration * 0.0f;
                velocity = velocity * 0.9f;
                vehiclePosition += velocity;
            }

            // checks if the user is close to stopped (near 0 velocity) and sets it to be 0
            else if(velocity.magnitude <= 0.01)
            {
                acceleration = acceleration * 0.0f;
                velocity = velocity * 0.0f;
                vehiclePosition += velocity;
            }


        }

    }

    // moves the player
    void MoveVehicle()
    {
        transform.position = vehiclePosition;
    }

    // property for direction
    public Vector3 Direction()
    {
        return direction;
    }

    // method to wrap the vehicle around the screen
    void WrapScreen()
    {
        vehiclePosition = transform.position;

        // goes off left
        if (vehiclePosition.x < -(viewWidth / 2.0f))
        {
            vehiclePosition.x = vehiclePosition.x + viewWidth;
        }

        // goes off right
        if (vehiclePosition.x > (viewWidth / 2.0f))
        {
            vehiclePosition.x = vehiclePosition.x - viewWidth;
        }

        // goes off top
        if (vehiclePosition.y > (viewHeight / 2.0f))
        {
            vehiclePosition.y = vehiclePosition.y - viewHeight;
        }

        // goes off bottom
        if (vehiclePosition.y < -(viewHeight / 2.0f))
        {
            vehiclePosition.y = vehiclePosition.y + viewHeight;
        }

        transform.position = vehiclePosition;
    }

}
