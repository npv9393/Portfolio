﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GameGUI : MonoBehaviour {

    public Score score;
    public PlayerDestroy playerDeath;
    private int lives;
    public Texture livesIcon;

	// Use this for initialization
	void Start () {
        lives = playerDeath.Lives;
	}
	
	// Update is called once per frame
	void Update () {
        lives = playerDeath.Lives;
    }

    void OnGUI()
    {
        // set GUI style
        GUI.skin.box.alignment = TextAnchor.UpperLeft;
        GUI.skin.box.fontSize = 30;
        // GUI.skin.box.fontStyle
        GUI.backgroundColor = Color.clear;
        GUI.contentColor = Color.white;

        // lives
        GUI.Box(new Rect(1, 1, 300, 50), "Lives:");

        // draws life images dependent on number of lives
        switch (lives)
        {
            case 1:
                GUI.DrawTexture(new Rect(100, 1, 32, 32), livesIcon);
                break;                           
                                                 
            case 2:                              
                GUI.DrawTexture(new Rect(100, 1, 32, 32), livesIcon);
                GUI.DrawTexture(new Rect(133, 1, 32, 32), livesIcon);
                break;                           
                                                 
            case 3:                              
                GUI.DrawTexture(new Rect(100, 1, 32, 32), livesIcon);
                GUI.DrawTexture(new Rect(133, 1, 32, 32), livesIcon);
                GUI.DrawTexture(new Rect(166, 1, 32, 32), livesIcon);
                break;
        }

        // player score
        GUI.Box(new Rect(1, 51, 300, 40) , "Score: "+ score.PlayerScore);
    }
}
