﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ScreenWrapping : MonoBehaviour {

    public Camera gameView;
    private float viewWidth;
    private float viewHeight;
    private Vector3 newPosition;

	// Use this for initialization
	void Start () {
        viewHeight = gameView.orthographicSize * 2.0f;
        viewWidth = viewHeight * gameView.aspect;
    }

    // Update is called once per frame
    void Update ()
    {
        WrapScreen();
    }

    // method to wrap the vehicle around the screen
    void WrapScreen()
    {
        newPosition = transform.position;

        // goes off left
        if (newPosition.x < -(viewWidth / 2.0f))
        {
            newPosition.x = newPosition.x + viewWidth;
        }

        // goes off right
        if (newPosition.x > (viewWidth / 2.0f))
        {
            newPosition.x = newPosition.x - viewWidth;
        }

        // goes off top
        if (newPosition.y > (viewHeight / 2.0f))
        {
            newPosition.y = newPosition.y - viewHeight;
        }

        // goes off bottom
        if (newPosition.y < -(viewHeight / 2.0f))
        {
            newPosition.y = newPosition.y + viewHeight;
        }

        transform.position = newPosition;
    }
}
