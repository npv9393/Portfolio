﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerDestroy : MonoBehaviour {

    public float IFrameTime;
    private float IFrameTimer;
    private bool IFrameActive;
    private Camera gameView;
    private float viewWidth;
    private float viewHeight;
    private Vector3 centerScreen;
    public int lives;
    public GameObject asteroidManager;
    public AsteroidSpawn asteroidSpawnScript;
    public List<GameObject> asteroids;
    public float playerDistance;
    public GameObject gameManager;
    public EnemySpawn enemySpawn;
    public Enemyshoot shootScript;

    // Use this for initialization
    void Start () {
        IFrameActive = false;
        gameView = Camera.main;
        viewHeight = gameView.orthographicSize * 2.0f;
        viewWidth = viewHeight * gameView.aspect;

        centerScreen = new Vector3(viewWidth / 2, viewHeight / 2, 1);

        lives = 3;

        asteroidManager = GameObject.Find("Asteroid Manager");
        asteroidSpawnScript = asteroidManager.GetComponent<AsteroidSpawn>();
        asteroids = asteroidSpawnScript.asteroidList;

        gameManager = GameObject.Find("Game Manager");
        enemySpawn = gameManager.GetComponent<EnemySpawn>();
    }
	
	// Update is called once per frame
	void Update ()
    {
        PlayerCollided();   
	}

    // checks for player colliding with anything but their own bullets
    void PlayerCollided()
    {
        // asteroid collision
        for (int i = 0; i < asteroids.Count; i++)
        {
            playerDistance = Mathf.Sqrt(Mathf.Pow((gameObject.transform.position.x - asteroids[i].transform.position.x), 2) + Mathf.Pow((gameObject.transform.position.y - asteroids[i].transform.position.y), 2));
            float playerSphere = gameObject.GetComponent<SpriteRenderer>().bounds.extents.magnitude;
            float asteroidSphere = asteroids[i].GetComponent<SpriteRenderer>().bounds.extents.magnitude;

            if (playerDistance < (playerSphere + asteroidSphere)- 1.0f && !IFrameActive)
            {
                Debug.Log("Player Collided with asteroid");
                lives -= 1;
                IFrameActive = true;
                IFrameTimer = IFrameTime;
            }
            if (IFrameTimer > 0.0f)
            {
                IFrameTimer -= Time.deltaTime;
                gameObject.GetComponent<SpriteRenderer>().color = Color.red;
            }

            if (IFrameTimer < 0.0f)
            {
                IFrameTimer = 0.0f;
                IFrameActive = false;
                gameObject.GetComponent<SpriteRenderer>().color = Color.white;
            }           
        }

        // tests for enemy and enemy bullet collision
        for(int j = 0; j < enemySpawn.enemyList.Count; j++)
        {
            Debug.Log("Enemy List count: "+enemySpawn.enemyList.Count);

            shootScript = enemySpawn.enemyList[j].GetComponentInChildren<Enemyshoot>();

            Debug.Log("Enemy Speed"+shootScript.bulletSpeed);

            playerDistance = Mathf.Sqrt(Mathf.Pow((gameObject.transform.position.x - enemySpawn.enemyList[j].transform.position.x), 2) + Mathf.Pow((gameObject.transform.position.y - enemySpawn.enemyList[j].transform.position.y), 2));
            float playerSphere = gameObject.GetComponent<SpriteRenderer>().bounds.extents.magnitude;
            float enemySphere = enemySpawn.enemyList[j].GetComponent<SpriteRenderer>().bounds.extents.magnitude;

            if (playerDistance < (playerSphere + enemySphere) - 1.0f && !IFrameActive)
            {
                Debug.Log("Player Collided with enemy");
                lives -= 1;
                IFrameActive = true;
                IFrameTimer = IFrameTime;
            }
            if (IFrameTimer > 0.0f)
            {
                IFrameTimer -= Time.deltaTime;
                gameObject.GetComponent<SpriteRenderer>().color = Color.red;
            }

            if (IFrameTimer < 0.0f)
            {
                IFrameTimer = 0.0f;
                IFrameActive = false;
                gameObject.GetComponent<SpriteRenderer>().color = Color.white;
            }

            Debug.Log(shootScript.bulletList.Count);

            // loop to test each enemies bullets
            for(int h = 0; h < shootScript.bulletList.Count; h++)
            {
                if (shootScript.bulletList[h] != null)
                {

                    float distance = Mathf.Sqrt(Mathf.Pow((gameObject.transform.position.x - shootScript.bulletList[h].transform.position.x), 2) + Mathf.Pow((gameObject.transform.position.y - shootScript.bulletList[h].transform.position.y), 2));
                    float playerCircle = gameObject.GetComponent<SpriteRenderer>().bounds.extents.magnitude;
                    float enemyBulletSphere = shootScript.bulletList[h].GetComponent<SpriteRenderer>().bounds.extents.magnitude;

                    if (distance < playerCircle + enemyBulletSphere && !IFrameActive)
                    {
                        Debug.Log("Player Collided with enemy bullet");
                        lives -= 1;
                        IFrameActive = true;
                        IFrameTimer = IFrameTime;
                    }
                    if (IFrameTimer > 0.0f)
                    {
                        IFrameTimer -= Time.deltaTime;
                        gameObject.GetComponent<SpriteRenderer>().color = Color.red;
                    }

                    if (IFrameTimer < 0.0f)
                    {
                        IFrameTimer = 0.0f;
                        IFrameActive = false;
                        gameObject.GetComponent<SpriteRenderer>().color = Color.white;
                    }

                }
            }
        }

    }


    /// <summary>
    /// Gets number of lives the player has
    /// </summary>
    public int Lives
    {
        get { return lives; }
    }
}
