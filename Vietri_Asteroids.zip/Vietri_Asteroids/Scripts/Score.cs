﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Score : MonoBehaviour
{
    public int playerScore;
    public int asteroidScore;

    /// <summary>
    /// check the level of the asteroid destroyed and add the points based on the level             use singleton
    /// </summary>

    // Use this for initialization
    void Start ()
    {
        playerScore = 0;
        asteroidScore = 0;
    }
	
	// Update is called once per frame
	void Update ()
    {
        UpdateScore();
    }

    /// <summary>
    /// Updates the players score
    /// </summary>
    void UpdateScore()
    {
        playerScore += asteroidScore;
        asteroidScore = 0;  
    }

    /// <summary>
    /// gets the player's current score
    /// </summary>
    public int PlayerScore
    {
        get { return playerScore; }
    }

    /// <summary>
    /// temporary int to hold the value of a destroyed asteroid
    /// </summary>
    public int AsteroidScore
    {
        get { return asteroidScore; }
        set { asteroidScore = value; }
    }

}
