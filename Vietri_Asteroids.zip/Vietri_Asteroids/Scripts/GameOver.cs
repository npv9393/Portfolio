﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GameOver : MonoBehaviour {

    public GameObject gameManager;
    public Score score;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    // game over score and controls GUI
    private void OnGUI()
    {
        // set GUI style
        GUI.skin.box.alignment = TextAnchor.MiddleCenter;
        GUI.skin.box.fontSize = 70;
        GUI.backgroundColor = Color.clear;
        GUI.contentColor = Color.white;
        GUI.Box(new Rect(1, 1, Screen.width - 2, Screen.height - 2), "Press Enter to play again \nPress Shift to return to title");
    }
}
