﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
namespace Game1
{
    class Animator
    {
        private int frame;
        private double timeCounter;
        private double fps;
        private double timePerFrame;

        private List<Animation> animationBank;
        private SpriteBatch spriteBatch;

        public List<Animation> AnimationBank { get { return animationBank; } }
        public Animator(SpriteBatch spriteBatch)
        {
            animationBank = new List<Animation>();
            this.spriteBatch = spriteBatch;
            fps = 10;
            timePerFrame = 1.0 / fps;
        }
        /// <summary>
        /// Add to animation Bank
        /// </summary>
        /// <param name="spriteSheet"></param>
        public void AddToBank(Animation spriteSheet)
        {
            animationBank.Add(spriteSheet);
        }
        /// <summary>
        /// Loops through animationBank to find name
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        public Animation FindAnimation (string name)
        {
            for(int i =0; i < animationBank.Count; i++)
            {
                if(animationBank[i].AnimationName == name)
                {
                    return animationBank[i];
                }

            }
            return null;
        }
        /// <summary>
        /// Updates animation loops, run in update
        /// </summary>
        /// <param name="time"></param>
        public void UpdateAnimation(GameTime time, string name)
        {
            Animation temp = FindAnimation(name);
            timeCounter += time.ElapsedGameTime.TotalSeconds; //increment counter
            if(timeCounter >= timePerFrame)
            {
                frame++; //increment frame
                if(frame > temp.FrameCount) //reset frame count
                {
                    frame = 0;
                }
                timeCounter -= timePerFrame; //decrement counter 
            }
        }
        /// <summary>
        /// Draws the animation
        /// </summary>
        /// <param name="flipSprite"></param>
        public void DrawAnimation(SpriteEffects flipSprite, string animationName, Vector2 location)
        {
            Animation temp = FindAnimation(animationName);
            spriteBatch.Draw(temp.SpriteSheet,          //spriteSheet to animate
                location,                           //location of sprite
                new Rectangle(                      //location on spriteSheet
                    frame * temp.Width,         //xLocation
                    temp.YOffset,               //yLocation
                    temp.Width,                 //frame width
                    temp.Height),               //frame height
                Color.White,                        //color
                0f,                                 //rotation
                Vector2.Zero,                       //origin in image
                1.0f,                               //Scale
                flipSprite,                         //Orientation
                0f);                                //Layer Depth
        }

    }
}
