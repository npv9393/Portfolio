﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
namespace Game1
{
    class Animation
    {
        private string name;
        private Texture2D spriteSheet;
        private int frameCount;
        private int yOffset;
        private int width;
        private int height;

        public string AnimationName { get { return name; } }
        public Texture2D SpriteSheet { get { return spriteSheet; } }
        public int FrameCount { get { return frameCount; } }
        public int YOffset { get { return yOffset; } }
        public int Width { get { return width; } }
        public int Height { get { return height; } }
        /// <summary>
        /// Creates an animation object
        /// </summary>
        /// <param name="name"> animation name</param>
        /// <param name="spriteSheet">sprite sheet to get animation from</param>
        /// <param name="frameCount">amount of frames in animation</param>
        /// <param name="yOffset">animation position on sprite sheed</param>
        /// <param name="width">frame width</param>
        /// <param name="height">frame height</param>
        public Animation(string name, Texture2D spriteSheet, int frameCount, int yOffset, int width, int height)
        {
            this.name = name;
            this.spriteSheet = spriteSheet;
            this.frameCount = frameCount;
            this.yOffset = yOffset;
            this.width = width;
            this.height = height;
        }


    }
}
