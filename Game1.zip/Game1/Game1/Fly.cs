﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Game1
{
    public enum FlyAnimationState
    {
        idle,
        hurt,
        dead
    }

    class Fly : Agent
    {
        private FlyAnimationState flyState;
        public FlyAnimationState FlyState { get { return flyState; }set { flyState = value; } }
        /// <summary>
        /// Fly constructor
        /// </summary>
        /// <param name="vectPos">The position of the fly</param>
        /// <param name="friction">The friction of the enemy</param>
        /// <param name="speed">The speed (or desireForce) of the enemy</param>
        public Fly(Vector2 vectPos, float friction, float speed)
            : base(size: new Point(16,16), vectP: vectPos, sprite: null, fric: friction, desireFrc:speed) {

            flyState = FlyAnimationState.idle;
        }

        public void TrackPlayer(Player p)
        {
            Vector2 enemyDesire = p.VectorPosition - this.VectorPosition;
            
            DesiredDir = enemyDesire;
        }

        /// <summary>
        /// Attacks the player (stuns the player on contact)
        /// </summary>
        /// <param name="p">The player to attack</param>
        public void Attack(Player p)
        {
            if (this.CollidesWith(p) && !Stunned)
            {
                p.Stunned = true;
                
            }
        }
        

        public override void Draw(SpriteBatch sb)
        {
            // Please do not use individual flies'  draw method. Instead, call draw on flies.
        }/// <summary>
        /// updates the fly animation state
        /// </summary>
        public void FlyAnimationHandler()
        {
            if (Stunned)
            {
                flyState = FlyAnimationState.dead;
            }
            else
            {
                flyState = FlyAnimationState.idle;
            }
        }

    }
}
