﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Game1
{
    class Circle:AnimatedObject
    {
        public Point center;
        private int radius;

        public int X
        {
            get
            {
                return center.X;
            }
            set
            {
                center.X = value;
            }
        }

        public int Y
        {
            get
            {
                return center.Y;
            }
            set
            {
                center.Y = value;
            }
        }

        public Circle(Point center, int radius)
        {
            this.center = center;
            this.radius = radius;
            
        }

        public bool Intersects(Rectangle rect)
        {
            int circleDistanceX = Math.Abs(this.X - rect.Center.X);
            int circleDistanceY = Math.Abs(this.Y - rect.Center.Y);

            if (circleDistanceX > (rect.Width / 2 + this.radius)) { return false; }
            if (circleDistanceY > (rect.Height / 2 + this.radius)) { return false; }

            if (circleDistanceX <= (rect.Width / 2)) { return true; }
            if (circleDistanceY <= (rect.Height / 2)) { return true; }

            int cornerDistance_sq = (circleDistanceX - rect.Width / 2) * (circleDistanceX - rect.Width / 2) + (circleDistanceY - rect.Height / 2) * (circleDistanceY - rect.Height / 2);

            return (cornerDistance_sq <= (this.radius * this.radius));
        }

        public bool Intersects(Circle circ)
        {
            int deltaX = circ.center.X - this.center.X;
            int deltaY = circ.center.Y - this.center.Y;
            double distSquared = (deltaX * deltaX) + (deltaY * deltaY);
            int radiusSumSquared = (this.radius + circ.radius) * (this.radius + circ.radius);
            return distSquared <= radiusSumSquared;
        }

        public void Draw(SpriteBatch sb, Texture2D mySprite)
        {
            Rectangle drawRect = new Rectangle(center.X - radius, center.Y - radius, radius * 2, radius * 2);
            sb.Draw(mySprite, drawRect, Color.White);
        }
        public override bool ObjectDirection(Rectangle objComparison)
        {
            return false;
        }
    }
}
