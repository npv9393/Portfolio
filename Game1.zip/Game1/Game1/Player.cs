﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Game1
{

    /// <summary>
    /// Player Class. For now, it's the same as its parent class
    /// Written by Ricardo Aguilera, Jerrold Wexler, Kesavan Shanmugasundaram, Noah Vietri
    /// </summary>
    public enum PlayerAnimationState
    {
        idle,
        walk,
        hurt,
        dead,
        attack
    }
    class Player : Agent
    {
        //Player Animation States
        private PlayerAnimationState playerState;
        public PlayerAnimationState PlayerState { get { return playerState; } set { playerState = value; } }
        // Size of player's attack
        public int AttackRadius { get; set; }
        public float AttackPower { get; set; }

        public bool alive;
        
        public Vector2 AttackVector
        {
            get {
                // The direction of the velocity of the player
                return (velocity == Vector2.Zero)
                        ? Vector2.UnitY
                        : Vector2.Normalize(velocity);
            }
        }

        public Rectangle CollisionRect
        {
            get { return new Rectangle(new Point(8,8) + PointPosition, CollisionSize); }
        }

        // The circle occupied by the player's attack
        public Circle AttackCircle
        {
            get
            {


                // The offset from the player (it is offset by the size of the attack radius)
                // If the player has no velocity, offset downward
                Vector2 vectOffset = AttackVector*AttackRadius;

                // The offset, converted to a point
                Point ptOffset = new Point((int)vectOffset.X, (int)vectOffset.Y);
                
                // The circle at that offset point
                return new Circle(this.CollisionRect.Center + ptOffset, this.AttackRadius);
            }
        }

        /// <summary>
        /// Player constructor. Has a bunch of default values
        /// To use the form, edit the constructor to remove the magic values, making them arguments
        /// to the constructor.
        /// </summary>
        /// <param name="vectP"></param>
        public Player(Vector2 vectP)
            : base(new Point(16,16), vectP, null, fric:15f, desireFrc:9000f) {
            AttackRadius = 80;
            AttackPower = 65536f;
            playerState = PlayerAnimationState.idle;
            alive = true;
        }
        
        /// <summary>
        /// Attacks enemies
        /// </summary>
        /// <param name="enemies">Enumerable of all enemies</param>
        public void Attack(IEnumerable<Fly> enemies)
        {
            playerState = PlayerAnimationState.attack;
            foreach (Fly enemy in enemies)
            {
                if (AttackCircle.Intersects(enemy.CollisionRect))
                {
                    enemy.AddForce(AttackVector * AttackPower);
                    enemy.Stunned = true;
                }
            }
        }

        public void PlayerUpdate(float deltaTime, Rectangle walkAbleBounds)
        {
            base.Update(deltaTime);
            if (!walkAbleBounds.Contains(DrawRect))
            {
                this.Die();
            }
        }

        public void Die()
        {
            playerState = PlayerAnimationState.dead;
            alive = false;
        }
    }
}
