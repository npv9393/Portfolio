﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace Game1
{
    class Menu
    {
        private SpriteFont gameText;
        //private Texture2D menuBackground;
        private SpriteBatch spriteBatch;
        private string playText;
        private string optionsText;
        private string quitText;

        Vector2 playPos;
        Vector2 optionsPos;
        Vector2 quitPos;

        public Menu(SpriteFont gameText, SpriteBatch spriteBatch)
        {
            this.gameText = gameText;
            this.spriteBatch = spriteBatch;

            playText = "Press [Enter] to Play!";
            optionsText = "Press [O] for Options";
            quitText = "Press [Escape] to Quit";

            playPos = new Vector2(20, 20);
            optionsPos = new Vector2(20, 100);
            quitPos = new Vector2(20, 180);
        }

        public void DrawMenu()
        {
            spriteBatch.DrawString(gameText, playText, playPos, Color.White);
            spriteBatch.DrawString(gameText, optionsText, optionsPos, Color.LightGray);
            spriteBatch.DrawString(gameText, quitText, quitPos, Color.White);
        }
    }
}
