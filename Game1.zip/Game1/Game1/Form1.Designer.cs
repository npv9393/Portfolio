﻿namespace Game1
{
    partial class DataEditorForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DataEditorForm));
            this.InitialEnemyNumberLabel = new System.Windows.Forms.Label();
            this.ScoreValueLabel = new System.Windows.Forms.Label();
            this.PlayerSpeedLabel = new System.Windows.Forms.Label();
            this.EnemySpeedLabel = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.EnemyNumber = new System.Windows.Forms.NumericUpDown();
            this.EnemyScoreValue = new System.Windows.Forms.NumericUpDown();
            this.PlayerSpeed = new System.Windows.Forms.NumericUpDown();
            this.EnemySpeed = new System.Windows.Forms.NumericUpDown();
            this.EnemyStun = new System.Windows.Forms.NumericUpDown();
            this.PlayerKnockback = new System.Windows.Forms.NumericUpDown();
            this.Enter = new System.Windows.Forms.Button();
            this.EnemiesAdded = new System.Windows.Forms.NumericUpDown();
            this.DeathOrbSpeed = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.OrbFrequency = new System.Windows.Forms.NumericUpDown();
            ((System.ComponentModel.ISupportInitialize)(this.EnemyNumber)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.EnemyScoreValue)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PlayerSpeed)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.EnemySpeed)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.EnemyStun)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PlayerKnockback)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.EnemiesAdded)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DeathOrbSpeed)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.OrbFrequency)).BeginInit();
            this.SuspendLayout();
            // 
            // InitialEnemyNumberLabel
            // 
            this.InitialEnemyNumberLabel.AutoSize = true;
            this.InitialEnemyNumberLabel.Font = new System.Drawing.Font("Castellar", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.InitialEnemyNumberLabel.Location = new System.Drawing.Point(19, 51);
            this.InitialEnemyNumberLabel.Name = "InitialEnemyNumberLabel";
            this.InitialEnemyNumberLabel.Size = new System.Drawing.Size(455, 39);
            this.InitialEnemyNumberLabel.TabIndex = 2;
            this.InitialEnemyNumberLabel.Text = "Initial Enemy Number";
            // 
            // ScoreValueLabel
            // 
            this.ScoreValueLabel.AutoSize = true;
            this.ScoreValueLabel.Font = new System.Drawing.Font("Castellar", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ScoreValueLabel.Location = new System.Drawing.Point(19, 188);
            this.ScoreValueLabel.Name = "ScoreValueLabel";
            this.ScoreValueLabel.Size = new System.Drawing.Size(395, 39);
            this.ScoreValueLabel.TabIndex = 3;
            this.ScoreValueLabel.Text = "Enemy Score Value";
            // 
            // PlayerSpeedLabel
            // 
            this.PlayerSpeedLabel.AutoSize = true;
            this.PlayerSpeedLabel.Font = new System.Drawing.Font("Castellar", 24F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PlayerSpeedLabel.Location = new System.Drawing.Point(639, 51);
            this.PlayerSpeedLabel.Name = "PlayerSpeedLabel";
            this.PlayerSpeedLabel.Size = new System.Drawing.Size(263, 39);
            this.PlayerSpeedLabel.TabIndex = 4;
            this.PlayerSpeedLabel.Text = "Player Speed";
            // 
            // EnemySpeedLabel
            // 
            this.EnemySpeedLabel.AutoSize = true;
            this.EnemySpeedLabel.Font = new System.Drawing.Font("Castellar", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EnemySpeedLabel.Location = new System.Drawing.Point(19, 257);
            this.EnemySpeedLabel.Name = "EnemySpeedLabel";
            this.EnemySpeedLabel.Size = new System.Drawing.Size(253, 39);
            this.EnemySpeedLabel.TabIndex = 5;
            this.EnemySpeedLabel.Text = "Enemy Speed";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Castellar", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(19, 333);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(348, 39);
            this.label4.TabIndex = 6;
            this.label4.Text = "Enemy Stun Time";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Castellar", 24F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(633, 115);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(396, 39);
            this.label5.TabIndex = 7;
            this.label5.Text = "Player Knockback";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Castellar", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(19, 115);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(493, 39);
            this.label6.TabIndex = 8;
            this.label6.Text = "Enemies Added Per Wave";
            // 
            // EnemyNumber
            // 
            this.EnemyNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EnemyNumber.Location = new System.Drawing.Point(518, 51);
            this.EnemyNumber.Name = "EnemyNumber";
            this.EnemyNumber.Size = new System.Drawing.Size(83, 31);
            this.EnemyNumber.TabIndex = 11;
            this.EnemyNumber.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.EnemyNumber.ValueChanged += new System.EventHandler(this.EnemyNumber_ValueChanged);
            // 
            // EnemyScoreValue
            // 
            this.EnemyScoreValue.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EnemyScoreValue.Location = new System.Drawing.Point(518, 197);
            this.EnemyScoreValue.Name = "EnemyScoreValue";
            this.EnemyScoreValue.Size = new System.Drawing.Size(83, 31);
            this.EnemyScoreValue.TabIndex = 12;
            this.EnemyScoreValue.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.EnemyScoreValue.ValueChanged += new System.EventHandler(this.EnemyScoreValue_ValueChanged);
            // 
            // PlayerSpeed
            // 
            this.PlayerSpeed.DecimalPlaces = 2;
            this.PlayerSpeed.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PlayerSpeed.Increment = new decimal(new int[] {
            5,
            0,
            0,
            131072});
            this.PlayerSpeed.Location = new System.Drawing.Point(1061, 61);
            this.PlayerSpeed.Maximum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.PlayerSpeed.Minimum = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.PlayerSpeed.Name = "PlayerSpeed";
            this.PlayerSpeed.Size = new System.Drawing.Size(83, 31);
            this.PlayerSpeed.TabIndex = 13;
            this.PlayerSpeed.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.PlayerSpeed.ValueChanged += new System.EventHandler(this.PlayerSpeed_ValueChanged);
            // 
            // EnemySpeed
            // 
            this.EnemySpeed.DecimalPlaces = 2;
            this.EnemySpeed.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EnemySpeed.Increment = new decimal(new int[] {
            5,
            0,
            0,
            131072});
            this.EnemySpeed.Location = new System.Drawing.Point(518, 269);
            this.EnemySpeed.Maximum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.EnemySpeed.Minimum = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.EnemySpeed.Name = "EnemySpeed";
            this.EnemySpeed.Size = new System.Drawing.Size(83, 31);
            this.EnemySpeed.TabIndex = 14;
            this.EnemySpeed.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.EnemySpeed.ValueChanged += new System.EventHandler(this.EnemySpeed_ValueChanged);
            // 
            // EnemyStun
            // 
            this.EnemyStun.DecimalPlaces = 2;
            this.EnemyStun.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EnemyStun.Location = new System.Drawing.Point(518, 342);
            this.EnemyStun.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.EnemyStun.Name = "EnemyStun";
            this.EnemyStun.Size = new System.Drawing.Size(83, 31);
            this.EnemyStun.TabIndex = 15;
            this.EnemyStun.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.EnemyStun.ValueChanged += new System.EventHandler(this.EnemyStun_ValueChanged);
            // 
            // PlayerKnockback
            // 
            this.PlayerKnockback.DecimalPlaces = 2;
            this.PlayerKnockback.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PlayerKnockback.Location = new System.Drawing.Point(1061, 122);
            this.PlayerKnockback.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.PlayerKnockback.Name = "PlayerKnockback";
            this.PlayerKnockback.Size = new System.Drawing.Size(83, 31);
            this.PlayerKnockback.TabIndex = 16;
            this.PlayerKnockback.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.PlayerKnockback.ValueChanged += new System.EventHandler(this.PlayerKnockback_ValueChanged);
            // 
            // Enter
            // 
            this.Enter.BackColor = System.Drawing.Color.Chartreuse;
            this.Enter.Font = new System.Drawing.Font("Castellar", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Enter.Location = new System.Drawing.Point(561, 462);
            this.Enter.Name = "Enter";
            this.Enter.Size = new System.Drawing.Size(158, 48);
            this.Enter.TabIndex = 18;
            this.Enter.Text = "Enter Changes";
            this.Enter.UseVisualStyleBackColor = false;
            this.Enter.Click += new System.EventHandler(this.Enter_Click);
            // 
            // EnemiesAdded
            // 
            this.EnemiesAdded.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EnemiesAdded.Location = new System.Drawing.Point(518, 122);
            this.EnemiesAdded.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.EnemiesAdded.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.EnemiesAdded.Name = "EnemiesAdded";
            this.EnemiesAdded.Size = new System.Drawing.Size(83, 31);
            this.EnemiesAdded.TabIndex = 17;
            this.EnemiesAdded.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.EnemiesAdded.ValueChanged += new System.EventHandler(this.EnemiesAdded_ValueChanged);
            // 
            // DeathOrbSpeed
            // 
            this.DeathOrbSpeed.DecimalPlaces = 2;
            this.DeathOrbSpeed.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DeathOrbSpeed.Increment = new decimal(new int[] {
            5,
            0,
            0,
            131072});
            this.DeathOrbSpeed.Location = new System.Drawing.Point(1060, 189);
            this.DeathOrbSpeed.Maximum = new decimal(new int[] {
            6,
            0,
            0,
            0});
            this.DeathOrbSpeed.Minimum = new decimal(new int[] {
            5,
            0,
            0,
            131072});
            this.DeathOrbSpeed.Name = "DeathOrbSpeed";
            this.DeathOrbSpeed.Size = new System.Drawing.Size(84, 31);
            this.DeathOrbSpeed.TabIndex = 22;
            this.DeathOrbSpeed.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.DeathOrbSpeed.ValueChanged += new System.EventHandler(this.DeathOrbSpeed_ValueChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Castellar", 24F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(633, 189);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(338, 39);
            this.label2.TabIndex = 21;
            this.label2.Text = "Death Orb Speed";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Castellar", 24F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(639, 261);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(319, 39);
            this.label1.TabIndex = 23;
            this.label1.Text = "Orb Frequency";
            // 
            // OrbFrequency
            // 
            this.OrbFrequency.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OrbFrequency.Location = new System.Drawing.Point(1060, 269);
            this.OrbFrequency.Maximum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.OrbFrequency.Minimum = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.OrbFrequency.Name = "OrbFrequency";
            this.OrbFrequency.Size = new System.Drawing.Size(83, 31);
            this.OrbFrequency.TabIndex = 24;
            this.OrbFrequency.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.OrbFrequency.ValueChanged += new System.EventHandler(this.OrbFrequency_ValueChanged);
            // 
            // DataEditorForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Chartreuse;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1184, 561);
            this.Controls.Add(this.OrbFrequency);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.DeathOrbSpeed);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Enter);
            this.Controls.Add(this.EnemiesAdded);
            this.Controls.Add(this.PlayerKnockback);
            this.Controls.Add(this.EnemyStun);
            this.Controls.Add(this.EnemySpeed);
            this.Controls.Add(this.PlayerSpeed);
            this.Controls.Add(this.EnemyScoreValue);
            this.Controls.Add(this.EnemyNumber);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.EnemySpeedLabel);
            this.Controls.Add(this.PlayerSpeedLabel);
            this.Controls.Add(this.ScoreValueLabel);
            this.Controls.Add(this.InitialEnemyNumberLabel);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "DataEditorForm";
            this.Text = "Stat Editor";
            ((System.ComponentModel.ISupportInitialize)(this.EnemyNumber)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.EnemyScoreValue)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PlayerSpeed)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.EnemySpeed)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.EnemyStun)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PlayerKnockback)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.EnemiesAdded)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DeathOrbSpeed)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.OrbFrequency)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label AddedDeathOrb;
        private System.Windows.Forms.Label InitialEnemyNumberLabel;
        private System.Windows.Forms.Label ScoreValueLabel;
        private System.Windows.Forms.Label PlayerSpeedLabel;
        private System.Windows.Forms.Label EnemySpeedLabel;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.NumericUpDown EnemyNumber;
        private System.Windows.Forms.NumericUpDown EnemyScoreValue;
        private System.Windows.Forms.NumericUpDown PlayerSpeed;
        private System.Windows.Forms.NumericUpDown EnemySpeed;
        private System.Windows.Forms.NumericUpDown EnemyStun;
        private System.Windows.Forms.NumericUpDown PlayerKnockback;
        private System.Windows.Forms.Button Enter;
        private System.Windows.Forms.NumericUpDown EnemiesAdded;
        private System.Windows.Forms.NumericUpDown DeathOrbSpeed;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NumericUpDown OrbFrequency;
    }
}