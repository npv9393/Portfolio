﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace Game1
{
    /// <summary>
    /// Struct for 2d coordinates
    /// Overloads operators to make writing code with it simpler
    /// Interchangeable with Point
    /// </summary>
    public struct CoOrd
    {
        public int X;
        public int Y;

        public CoOrd(int x, int y)
        {
            X = x;
            Y = y;
        }

        /// <summary>
        /// Componentwise addition of two coords
        /// </summary>
        /// <param name="c1">Addend</param>
        /// <param name="c2">Addend</param>
        /// <returns>Sum</returns>
        public static CoOrd operator +(CoOrd c1, CoOrd c2)
        {
            return new CoOrd(c1.X + c2.X, c1.Y + c2.Y);
        }


        /// <summary>
        /// Componentwise subtraction of two coords
        /// </summary>
        /// <param name="c1">Minuend</param>
        /// <param name="c2">Subtrahend</param>
        /// <returns>Difference</returns>
        public static CoOrd operator -(CoOrd c1, CoOrd c2)
        {
            return new CoOrd(c1.X - c2.X, c1.Y - c2.Y);
        }

        /// <summary>
        /// Scalar multiplication of a coord
        /// </summary>
        /// <param name="d">The scalar</param>
        /// <param name="c">The coordinate</param>
        /// <returns>The coordinate, scaled by a factor of d</returns>
        public static CoOrd operator *(double d, CoOrd c)
        {
            int newX = (int) Math.Round(c.X * d);
            int newY = (int) Math.Round(c.Y * d);

            return new CoOrd(newX, newY);
        }
        // Declared twice for commutativity
        public static CoOrd operator *(CoOrd c, double d)
        {
            int newX = (int)Math.Round(c.X * d);
            int newY = (int)Math.Round(c.Y * d);

            return new CoOrd(newX, newY);
        }

        /// <summary>
        /// Adds a point and a coordinate, returning a point
        /// </summary>
        /// <param name="p"></param>
        /// <param name="c"></param>
        /// <returns></returns>
        public static Point operator +(Point p, CoOrd c)
        {
            return new Point(p.X + c.X, p.Y + c.Y);
        }
        // Declared twice for commutativity
        public static Point operator +(CoOrd c, Point p)
        {
            return new Point(p.X + c.X, p.Y + c.Y);
        }

        /// <summary>
        /// Converts from CoOrd to Point
        /// </summary>
        /// <param name="c">The coordinate to convert</param>
        public static implicit operator Point(CoOrd c)
        {
            return new Point(c.X, c.Y);
        }

        /// <summary>
        /// Converts from Point to CoOrd
        /// </summary>
        /// <param name="p">The point to convert</param>
        public static implicit operator CoOrd(Point p)
        {
            return new CoOrd(p.X, p.Y);
        }
    }
}
