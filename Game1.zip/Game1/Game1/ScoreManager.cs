﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game1
{
    class ScoreManager
    {
        private int score;
        public int Score { get { return score; } set { score = value; } }

        public ScoreManager()
        {
            score = 0;
        }

        public void AddScore(int scoreToAdd)
        {
            score += scoreToAdd;
        }
    }
}
