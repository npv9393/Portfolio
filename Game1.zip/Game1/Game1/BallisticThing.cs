﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Game1
{

    /// <summary>
    /// Class for things that are affected by physics forces
    /// These include momentum and friction.
    /// Written by Ricardo Aguilera, Jerrold Wexler, Kesavan Shanmugasundaram, Noah Vietri
    /// </summary>
    
    
    class BallisticThing : AnimatedObject
    {

        public Point PointPosition
        {
            get { return new Point((int)VectorPosition.X, (int)VectorPosition.Y); } 
        }

        public Point CollisionSize { get;  set; }
        public Point DrawSize { get;  set; }

        public Rectangle CollisionRect
        {
            get { return new Rectangle(PointPosition, CollisionSize); }
        }
        public Rectangle DrawRect
        {
            get { return new Rectangle(PointPosition, DrawSize); }
        }

        public Texture2D Sprite { get; set; }

        public Vector2 VectorPosition { get; set; }
        protected Vector2 velocity;
        protected Vector2 forces;

        protected float friction;


        /// <summary>
        /// Make a new ballistic thing
        /// </summary>
        /// <param name="size">Size of the new thing</param>
        /// <param name="vectP">The position of the new thing</param>
        /// <param name="sprite">The sprite of the new thing</param>
        /// <param name="fric">The friction of the new thing</param>
        public BallisticThing(Point size, Vector2 vectP, Texture2D sprite, float fric)
        {
            CollisionSize = size;
            DrawSize = size;
            VectorPosition = vectP;
            Sprite = sprite;
            friction = fric;
            
            velocity = Vector2.Zero;
            forces = Vector2.Zero;
        }
        
        /// <summary>
        /// Resets the forces acting on an object
        /// </summary>
        public void ResetForces()
        {
            forces = Vector2.Zero;
        }

        /// <summary>
        /// Adds a force to a ballistic thing
        /// </summary>
        /// <param name="forceToAdd">The force to add to the ballistic thing</param>
        public void AddForce(Vector2 forceToAdd)
        {
            forces += forceToAdd;
        }

        /// <summary>
        /// Updates the position of the ballistic thing
        /// </summary>
        /// <param name="deltaTime">Amount of time since the last Update call</param>
        public virtual void Update(float deltaTime)
        {
            ApplyForces(deltaTime);
        }

        /// <summary>
        /// Applies the forces acting on an object
        /// </summary>
        /// <param name="deltaTime">The amount of time since the last ApplyForces</param>
        public void ApplyForces(float deltaTime)
        {
            // Apply friction
            velocity *= Math.Max((1 - friction*deltaTime), 0f);

            //simplify deceleration
            if (Math.Abs(velocity.X) < 0.01)
            {
                velocity.X = 0;
            }
            if (Math.Abs(velocity.Y) < 0.01)
            {
                velocity.Y = 0;
            }

            // Next position = (Previous position) + (Previous velocity)*t + (1/2)*acceleration*t^2
            // (Acceleration formula)
            VectorPosition += velocity * (deltaTime);
            VectorPosition += forces * (0.5f * deltaTime * deltaTime);

            // Apply acceleration
            velocity += forces * deltaTime;
        }

        /// <summary>
        /// Draws the ballistic thing to the screen
        /// </summary>
        /// <param name="sb">The spritebatch that draws the thing</param>
        public virtual void Draw(SpriteBatch sb)
        {
            sb.Draw(Sprite, DrawRect, Color.White);
        }

        /// <summary>
        /// Repels this instance from a position
        /// The repulsion scales by a square factor as
        /// the ballistic thing gets closer to the point.
        /// 
        /// View graph here
        /// https://www.desmos.com/calculator/uvenr84ipd
        /// </summary>
        /// <param name="otherPos">The other position</param>
        /// <param name="personalSpace">The "personal space" -- scales the repulsion</param>
        /// <param name="maximumRepellence">The maximum repellence</param>
        protected void RepelFromPosition(Vector2 otherPos, float personalSpace, float maximumRepellence)
        {
            Vector2 vectorToOtherPos = otherPos - VectorPosition;
            Vector2 directionToOtherPos = Vector2.Normalize(vectorToOtherPos);

            float distanceSquared = vectorToOtherPos.LengthSquared();

            float repellencePower = Math.Min(maximumRepellence, personalSpace / distanceSquared);

            AddForce(repellencePower * -directionToOtherPos);
        }

        /// <summary>
        /// Repels another ballistic thing
        /// </summary>
        /// <param name="other">The other thing to repel</param>
        /// <param name="personalSpace">How strongly the things will repel each other</param>
        /// <param name="maximumRepellence">The maximum force with which the things will repel each other</param>
        public void RepelOtherBallisticThing(BallisticThing other, float personalSpace, float maximumRepellence)
        {
            // Add a force repelling the thing from the other
            this.RepelFromPosition(other.VectorPosition, personalSpace, maximumRepellence);

            // Add a force repelling the other from the thing
            other.RepelFromPosition(VectorPosition, personalSpace, maximumRepellence);
        }

        /// <summary>
        /// Detects collision with circles
        /// </summary>
        /// <param name="circlePosition">The position of the circle</param>
        /// <param name="circleRadius">The radius of the circle</param>
        /// <returns>Whether the ballisticThing collides with the circle</returns>
        public bool CollidesWith(Circle circle)
        {
            return circle.Intersects(this.CollisionRect);
        }

        /// <summary>
        /// Detects collision with rectangles
        /// </summary>
        /// <param name="rect">The rectangle with which to collide</param>
        /// <returns>Whether the ballisticThing collides with the rectangle</returns>
        public bool CollidesWith(Rectangle rect)
        {
            return CollisionRect.Intersects(rect);
        }

        /// <summary>
        /// Detects collision with ballistic things
        /// </summary>
        /// <param name="rect">The ballistic thing with which to collide</param>
        /// <returns>Whether the ballisticThing collides with the other ballistic thing</returns>
        public bool CollidesWith(BallisticThing bt)
        {
            return CollisionRect.Intersects(bt.CollisionRect);
        }


        public Vector2 Velocity
        {
            get { return velocity; }
            set { velocity = value; }
        }/// <summary>
        /// Returns true if facing left
        /// </summary>
        /// <param name="objComparison"> rectangle to compare to</param>
        /// <returns></returns>
        public override bool ObjectDirection(Rectangle objComparison)
        {
            if(DrawRect.X < objComparison.X)
            {
                return true;
            }
            return false;
        }
    }
}
