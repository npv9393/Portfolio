﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace Game1
{
    /// <summary>
    /// Class that keeps track of all flies in the game
    /// Flies need to be in a certain order to prevent unnecessary
    /// collision checking
    /// </summary>
    class Flies
    {
        public List<Fly> FlyList { get; }
        public Texture2D Texture { get; set; }

        public Flies(Texture2D texture)
        {
            FlyList = new List<Fly>();
            Texture = texture;
        }

        /// <summary>
        /// Repels enemies from each other
        /// </summary>
        /// <param name="enemies">The array of enemies</param>
        public void RepelEachOther()
        {
            for (int i = 0; i < FlyList.Count; i++)
            {
                Fly thisFly = FlyList[i];

                if (!FlyList[i].Stunned)
                {
                    // Start at the index after yours (don't check yourself or anyone
                    // that's already been checked against you)
                    for (int j = (i+1); j < FlyList.Count; j++)
                    {
                        Fly thatFly = FlyList[j];

                        // If the other enemy is not stunned
                        if (!thatFly.Stunned)
                            thisFly.RepelOtherBallisticThing(thatFly, personalSpace: 8192f, maximumRepellence: 32768f);
                    }
                }
            }
        }


        public void SetDesireForceOfAllFlies(float speed)
        {
            for (int i = 0; i < FlyList.Count; i++)
            {
                FlyList[i].DesireForceStat = speed;
            };
        }

        public void Attack(Player p)
        {
            for (int i = 0; i < FlyList.Count; i++)
            {
                FlyList[i].Attack(p);
            }
        }

        public void Update(float deltaTime)
        {
            for (int i = 0; i < FlyList.Count; i++)
            {
                FlyList[i].Update(deltaTime);
            }
        }
        
        public void ResetForces()
        {
            for (int i = 0; i < FlyList.Count; i++)
            {
                FlyList[i].ResetForces();
            }
        }

        public void TrackPlayer(Player p)
        {   
            for (int i = 0; i < FlyList.Count; i++)
            {
                FlyList[i].TrackPlayer(p);
            }
        }

        public void Draw(SpriteBatch sb)
        {
            for (int i = 0; i < FlyList.Count; i++)
            {
                Fly fly = FlyList[i];
                sb.Draw(Texture, fly.DrawRect, fly.Stunned ? Color.LightGray : Color.White);
            }
        }

        public int DieIfOffScreen(Rectangle containingRect)
        {
            int enemiesKilled = 0;
            // For loop going downwards because it involves
            // removing elements
            for (int i = FlyList.Count-1; i >= 0; i--)
            {
                if (!containingRect.Intersects(FlyList[i].DrawRect) && FlyList[i].Stunned) {
                    FlyList.RemoveAt(i);
                    enemiesKilled++;
                }
            }
            return enemiesKilled;
        }

    }
}
