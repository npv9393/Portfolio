﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Game1
{
    class MurderOrb : Agent
    {

        private Circle CollisionCircle
        {
            get
            {
                return new Circle(this.CollisionRect.Center, this.CollisionSize.X/2);
            }
        }

        public void SetSize(int newSize)
        {
            CollisionSize = new Point(newSize);
            DrawSize = new Point(newSize);
        }

        /// <summary>
        /// Murder Orb constructor
        /// </summary>
        /// <param name="vectPos">The position of the murder orb</param>
        /// <param name="friction">The friction of the orb</param>
        /// <param name="speed">The speed (or desireForce) of the orb</param>
        public MurderOrb(Vector2 vectPos, float friction, float speed, int size)
            : base(size: new Point(size,size), vectP: vectPos, sprite: null, fric: friction, desireFrc:speed) {

        }

        /// <summary>
        /// Tracks the player
        /// </summary>
        /// <param name="p"></param>
        public void TrackPlayer(Player p)
        {
            Vector2 enemyDesire = Vector2.Normalize(p.VectorPosition - this.VectorPosition);

            DesiredDir = enemyDesire;
        }

        /// <summary>
        /// Attacks the player (kills player on contact)
        /// </summary>
        /// <param name="p">The player to attack</param>
        public void Attack(Player p)
        {
            if (CollisionCircle.Intersects(p.CollisionRect))
            {
                p.Die();
            }
        }

        /// <summary>
        /// handles leaving the screen, returns true if it would leave the screen
        /// </summary>
        public void TryToUpdate(float deltaTime, Rectangle screen)
        {
            Vector2 prevPos = VectorPosition;

            Update(deltaTime);
            
            if (!screen.Contains(CollisionRect))
            {
                velocity = Vector2.Negate(velocity);
                VectorPosition = prevPos;
                this.ResetForces(); // makes it not freak out
            }
        }
    }
}
