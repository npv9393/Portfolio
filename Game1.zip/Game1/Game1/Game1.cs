﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

using System.Collections.Generic;
using System;

namespace Game1
{
    public enum GameState
    {
        Menu,
        Play,
        GameOver
    }

    /// <summary>
    /// Ricardo Aguilera is in the room...
    /// K7
    /// Noah is here
    /// Jerry Arrived
    /// </summary>
    public class Game1 : Game
    {
        #region Fields
        //Animations
        //TennisBall Monsters
        private Texture2D enemySpriteSheet;
        private Animation enemyIdle;
        private Animation enemyDeath;
        private Animation enemyHurt;
        private Texture2D murderOrbBase;
        //Player
        private Texture2D playerSpriteSheet;
        private Animation playerIdle;
        private Animation playerRun;
        //Game Over
        private Texture2D gameOverText;
        private Rectangle gameOverFill;
        //GameField
        private Texture2D gameField;
        //Title Screen
        private Texture2D titleScreen;

        private GraphicsDeviceManager graphics;
        private SpriteBatch spriteBatch;

        private GameState gameState;

        private SpriteFont gameText;

        private KeyboardState oldKBState;
        private KeyboardState newKBState;

        private Player player;
        private Texture2D attackImage;
        // A dictionary associating keyboard keys with directions
        private Dictionary<Keys, Vector2> controls;

        private Flies enemies;
        private int enemyCount;
        private int waveNumber;
        private int enemiesAddedPerWave;
        private Random randgen;
        private float enemyFric;
        private float enemySpeed;
        private int enemyScoreValue;
        private float murderOrbSpeed;
        private int orbFrequency;

        
        private List<MurderOrb> murderOrbs;

        private Menu menu;

        private DataEditorForm form;
        private StatFormManager formManager;
        private ScoreManager scoreManager = new ScoreManager();

        Circle testCircle = null;

        private Rectangle walkableArea;

        private const int SCREENWIDTH = 1820;
        private const int SCREENHEIGHT = 900;

        #endregion

        #region Game1 Constructor
        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            graphics.PreferredBackBufferHeight = SCREENHEIGHT;
            graphics.PreferredBackBufferWidth = SCREENWIDTH;

            randgen = new Random();
            enemyFric = 3f;
            enemySpeed = 2000f;

            Content.RootDirectory = "Content";

            gameState = GameState.Menu;
        }
        #endregion

        #region Initialize
        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            // Player
            player = new Player(Vector2.Zero);

            gameOverFill = new Rectangle(0, 0, SCREENWIDTH, SCREENHEIGHT);

            walkableArea = new Rectangle(-60, -60, SCREENWIDTH + 120, SCREENHEIGHT + 120);
            
            Random randgen = new Random();

            enemyCount = 10;
            waveNumber = 0;
            enemiesAddedPerWave = 5;
            enemyScoreValue = 10;
            murderOrbSpeed = 400f;
            orbFrequency = 2;
            

            enemies = new Flies(null);

            // Murder orb
            murderOrbs = new List<MurderOrb>();

            // Player controls
            controls = new Dictionary<Keys, Vector2>
            {
                { Keys.W, new Vector2( 0, -1) },
                { Keys.A, new Vector2(-1,  0) },
                { Keys.S, new Vector2( 0,  1) },
                { Keys.D, new Vector2( 1,  0) }
            };


            base.Initialize();

            menu = new Menu(gameText, spriteBatch);
        }
        #endregion

        #region Enemy Spawn
        private void SpawnEnemies()
        {
            for (int i = 0; i < enemyCount; i++)
            {
                const int breathingRoom = 300;
                float newFlyX = randgen.Next(SCREENWIDTH - breathingRoom);
                float newFlyY = randgen.Next(SCREENHEIGHT - breathingRoom);

                if (Math.Abs(newFlyX - player.CollisionRect.Center.X) < breathingRoom / 2)
                {
                    newFlyX += breathingRoom;
                }
                if (Math.Abs(newFlyY - player.CollisionRect.Center.Y) < breathingRoom / 2)
                {
                    newFlyY += breathingRoom;
                }
                enemies.FlyList.Add(
                    new Fly(new Vector2(newFlyX, newFlyY), enemyFric, enemySpeed)
                );
            }
            if ((waveNumber % orbFrequency) == 1)
            {
                if (player.CollisionRect.Center.X > SCREENWIDTH / 2)
                {
                    if (player.CollisionRect.Center.Y > SCREENHEIGHT / 2)
                    {
                        murderOrbs.Add(new MurderOrb(new Vector2(0, 0), friction: 50f, speed: murderOrbSpeed, size: 64));
                    }
                    else
                    {
                        murderOrbs.Add(new MurderOrb(new Vector2(0, SCREENHEIGHT-64), friction: 50f, speed: murderOrbSpeed, size: 64));
                    }
                }
                else
                {
                    if (player.CollisionRect.Center.Y > SCREENHEIGHT / 2)
                    {
                        murderOrbs.Add(new MurderOrb(new Vector2(SCREENWIDTH - 64, 0), friction: 50f, speed: murderOrbSpeed, size: 64));
                    }
                    else
                    {
                        murderOrbs.Add(new MurderOrb(new Vector2(SCREENWIDTH - 64, SCREENHEIGHT - 64), friction: 50f, speed: murderOrbSpeed, size: 64));
                    }
                }
                murderOrbs[murderOrbs.Count - 1].Sprite = murderOrbBase;
            }
            if (waveNumber > 1)
            {
                scoreManager.AddScore(100);
            }
            //loop through each fly in list and add
            foreach (Fly fly in enemies.FlyList)
            {
                //initialize each animator and add animations
                fly.animator = new Animator(spriteBatch);
                fly.animator.AddToBank(enemyIdle);
                fly.animator.AddToBank(enemyDeath);
                fly.animator.AddToBank(enemyHurt);
            }
            enemyCount += enemiesAddedPerWave;
        }
        #endregion

        #region Load/Unload
        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);
            //load animations
            //animator = new Animator(spriteBatch);
            //animator.AddToBank(new SpriteSheet(Content.Load<Texture2D>("SampleSpriteSheet"), 3, 0, 32, 32, "playerFrontWalk"));
            // animator.AddToBank(new SpriteSheet(Content.Load<Texture2D>("SampleSpriteSheet"), 1, 0, 32, 32, "playerFrontIdle"));
            gameText = Content.Load<SpriteFont>("arial16");

            //enemy animations
            enemySpriteSheet = Content.Load<Texture2D>("TennisBallMonsterSpriteSheet"); //spritesheet
            enemyIdle = new Animation("tennisballidle", enemySpriteSheet, 2, 0, 32, 32); //enemy idle
            enemyDeath = new Animation("tennisballdeath", enemySpriteSheet, 1, 32, 32, 32); //enemy death
            enemyHurt = new Animation("tennisballhurt", enemySpriteSheet, 2, 64, 32, 32); //enemy hurt
            //player animations
            playerSpriteSheet = Content.Load<Texture2D>("PlayerSpriteSheet"); //spritesheet
            playerIdle = new Animation("playeridle", playerSpriteSheet, 1, 0, 64, 64); //player idle
            playerRun = new Animation("playerrun", playerSpriteSheet, 4, 64, 64, 64); //player walk
            //Game Over
            gameOverText = Content.Load<Texture2D>("gameOverText");

            //loop through each fly in list and add
            foreach (Fly fly in enemies.FlyList)
            {
                //initialize each animator and add animations
                fly.animator = new Animator(spriteBatch);
                fly.animator.AddToBank(enemyIdle);
                fly.animator.AddToBank(enemyDeath);
                fly.animator.AddToBank(enemyHurt);
            }
            //initialize and add to player animator
            player.animator = new Animator(spriteBatch);
            player.animator.AddToBank(playerIdle);
            player.animator.AddToBank(playerRun);

            attackImage=Content.Load<Texture2D>("TennisRacquet"); //PLACEHOLDER NEED TO REPLACE

            murderOrbBase = Content.Load<Texture2D>("MurderOrb");

            //backgrounds
            gameField = Content.Load<Texture2D>("GameField");
            titleScreen = Content.Load<Texture2D>("TitleScreen");
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// game-specific content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }
        #endregion

        #region Update
        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();

            CheckKeyboardInput();

            switch (gameState)
            {
                case GameState.Menu:
                    #region Menu
                    // Menu state change
                    if (SingleKeyPress(Keys.Enter))
                    {
                        // Test flies
                        waveNumber = 0;
                        SpawnEnemies();
                        scoreManager.Score = 0;
                        gameState = GameState.Play;
                    }
                    if (SingleKeyPress(Keys.O))
                    {
                        form = new DataEditorForm();
                        form.Show();
                        formManager = new StatFormManager();
                    }
                    if (SingleKeyPress(Keys.Escape))
                    {
                        Exit();
                    }
                    // altering the stats
                    if (form != null && form.EnterClicked && form.IsDisposed)
                    {
                        formManager.ReadFile();
                        player.DesireForceStat = 14000f * formManager.PlayerSpeed;
                        enemyCount = (int)formManager.EnemyNumber;
                        for (int i = 0; i < enemies.FlyList.Count; i++)
                        {
                            enemies.FlyList[i].DesireForceStat = 2000f * formManager.EnemySpeed;

                        }
                        player.AttackPower = 65536f * formManager.PlayerKnockback;
                        enemyCount = (int)formManager.EnemyNumber;
                        enemiesAddedPerWave = (int)formManager.EnemiesAdded;
                        enemyScoreValue = (int)formManager.EnemyScoreValue;
                        orbFrequency = formManager.OrbFrequency;
                        murderOrbSpeed = (400f * formManager.DeathOrbSpeed);
                    }
                    #endregion
                    break;
                case GameState.Play:
                    #region Play
                    // Remove all forces at the start of each step
                    // This stops forces from compounding.

                    player.ResetForces();
                    enemies.ResetForces();
                    for (int i = 0; i < murderOrbs.Count - 1; i++) murderOrbs[i].RepelOtherBallisticThing(murderOrbs[i + 1], 800000, 32000);

                    enemies.TrackPlayer(player);
                    foreach (MurderOrb m in murderOrbs)
                    {
                        m.TrackPlayer(player);
                    }

                    //update player animations
                    switch (player.PlayerState)
                    {
                        case PlayerAnimationState.idle: //idle
                            player.animator.UpdateAnimation(gameTime, "playeridle");
                            break;
                        case PlayerAnimationState.walk: //walk
                            player.animator.UpdateAnimation(gameTime, "playerrun");
                            break;
                        case PlayerAnimationState.hurt:

                            break;
                        case PlayerAnimationState.attack:

                            break;
                        case PlayerAnimationState.dead:

                            break;

                    }


                    // By default (when nothing is pressed)
                    // the player has no desires
                    player.DesiredDir = Vector2.Zero;
                    foreach (Keys key in newKBState.GetPressedKeys())
                    {
                        if (player.alive)
                        {
                            // If one of the control keys is being pressed
                            if (controls.TryGetValue(key, out Vector2 desiredDir))
                            {
                                // The player wants to go in the direction of the key
                                if (key == Keys.A) //check if a is pressed
                                {
                                    player.FacingLeft = true; //player faces left
                                }
                                else if (key == Keys.D) //check if d is pressed
                                {
                                    player.FacingLeft = false; //player faces right
                                }
                                player.PlayerState = PlayerAnimationState.walk; //if keys are presse, set player to walk
                                player.DesiredDir += desiredDir;

                            }
                            else
                            {
                                player.PlayerState = PlayerAnimationState.idle; //else is idle
                            }
                        }
                        else
                        {
                            player.PlayerState = PlayerAnimationState.dead;
                        }
                    }

                    // Player attacks with space
                    if (SingleKeyPress(Keys.Space) && player.alive)
                    {
                        // Apply force for enemy knockback
                        player.Attack(enemies.FlyList);
                    }

                    // Update each enemy
                    enemies.RepelEachOther();
                    enemies.Attack(player);
                    enemies.Update(gameTime.ElapsedGameTime.Milliseconds / 1000.0f);
                    //enemies animations
                    for (int i = 0; i < enemies.FlyList.Count; i++)  //loop through enemies list
                    {
                        enemies.FlyList[i].FlyAnimationHandler(); //update each fly's animation state
                        enemies.FlyList[i].FacingLeft = enemies.FlyList[i].ObjectDirection(player.DrawRect); //check direction relative to player
                        switch (enemies.FlyList[i].FlyState)
                        {
                            case FlyAnimationState.idle:
                                enemies.FlyList[i].animator.UpdateAnimation(gameTime, "tennisballidle"); //update idle animation
                                break;
                            case FlyAnimationState.dead:
                                enemies.FlyList[i].animator.UpdateAnimation(gameTime, "tennisballdeath"); //update dead animation
                                break;
                        }
                    }
                    if (!player.alive)
                    {
                        gameState = GameState.GameOver;
                    }


                    // Update the murder orb
                    foreach (MurderOrb m in murderOrbs)
                    {
                        m.Attack(player);
                        m.TryToUpdate(gameTime.ElapsedGameTime.Milliseconds / 500.0f, GraphicsDevice.Viewport.Bounds);
                        
                    }

                    scoreManager.AddScore(enemies.DieIfOffScreen(GraphicsDevice.Viewport.Bounds) * enemyScoreValue);
                    if (enemies.FlyList.Count == 0)//if all enemies are dead
                    {
                        waveNumber++;
                        SpawnEnemies();
                    }
                    // Apply the forces and desires acting on the player
                    player.PlayerUpdate(gameTime.ElapsedGameTime.Milliseconds / 1000.0f, walkableArea);

                    //animations
                    //animator.UpdateAnimation(gameTime, "playerFrontWalk");
                    #endregion
                    break;
                case GameState.GameOver:
                    if (SingleKeyPress(Keys.Enter))
                    {
                        ResetGame();
                        gameState = GameState.Menu;
                    }
                    break;
            }

            // Update keyboard state
            base.Update(gameTime);
        }
        #endregion

        #region Draw
        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);
            spriteBatch.Begin();

            switch (gameState)
            {
                case GameState.Menu:
                    // Draw menu text
                    spriteBatch.Draw(titleScreen, new Rectangle(0, 0, 1820, 900), Color.White);
                    break;

                case GameState.Play:
                    #region Play
                    //Background
                    spriteBatch.Draw(gameField, new Rectangle(0, 0, 1820, 900), Color.White);

                    // Player info
                    //spriteBatch.DrawString(gameText, player.ToString(), new Vector2(10, 10), Color.White);
                    spriteBatch.DrawString(gameText, string.Format("Wave: {1} Score: {0}", scoreManager.Score, waveNumber), new Vector2(1820/2-100, 10), Color.White);
                    // Player itself
                    if (player != null) //check if player exists
                    {
                        switch (player.PlayerState)
                        {
                            case PlayerAnimationState.idle: //player idle
                                if (player.FacingLeft)
                                {
                                    player.animator.DrawAnimation(SpriteEffects.FlipHorizontally, "playeridle", new Vector2(player.PointPosition.X, player.PointPosition.Y)); //draw facing left
                                }
                                else
                                {
                                    player.animator.DrawAnimation(SpriteEffects.None, "playeridle", new Vector2(player.PointPosition.X, player.PointPosition.Y)); //draw facing right
                                }
                                break;
                            case PlayerAnimationState.walk: //walk
                                if (player.FacingLeft)
                                {
                                    player.animator.DrawAnimation(SpriteEffects.FlipHorizontally, "playerrun", new Vector2(player.PointPosition.X, player.PointPosition.Y)); //facing left
                                }
                                else
                                {
                                    player.animator.DrawAnimation(SpriteEffects.None, "playerrun", new Vector2(player.PointPosition.X, player.PointPosition.Y)); //facing right

                                }
                                break;
                            case PlayerAnimationState.hurt: //hurt
                                if (player.FacingLeft)
                                {

                                }
                                else
                                {

                                }
                                break;
                            case PlayerAnimationState.attack: //attack
                                if (player.FacingLeft)
                                {

                                }
                                else
                                {

                                }
                                break;
                            case PlayerAnimationState.dead: //dead
                                if (player.FacingLeft)
                                {

                                }
                                else
                                {

                                }
                                break;


                        }

                    }

                    //animator.DrawAnimation(SpriteEffects.None, "playerFrontWalk", new Vector2(player.PointPosition.X, player.PointPosition.Y));



                    //// Enemy info
                    //spriteBatch.DrawString(arial16, enemy.ToString(), new Vector2(10, 120), Color.White);
                    // Enemy itself
                    if (enemies.FlyList.Count > 0) //check if enemies exist
                    {
                        foreach (Fly fly in enemies.FlyList) //loop through each fly in enemies list 
                        {
                            //enemies.Draw(spriteBatch);

                            switch (fly.FlyState) //check each fly's state
                            {
                                case FlyAnimationState.idle: //idle
                                    if (fly.FacingLeft)
                                    {
                                        fly.animator.DrawAnimation(SpriteEffects.None, "tennisballidle", new Vector2(fly.PointPosition.X, fly.PointPosition.Y)); //draw facing left
                                    }
                                    else
                                    {
                                        fly.animator.DrawAnimation(SpriteEffects.FlipHorizontally, "tennisballidle", new Vector2(fly.PointPosition.X, fly.PointPosition.Y)); //draw facing right

                                    }
                                    break;
                                case FlyAnimationState.dead: //dead/stunned

                                    if (fly.FacingLeft)
                                    {
                                        fly.animator.DrawAnimation(SpriteEffects.None, "tennisballdeath", new Vector2(fly.PointPosition.X, fly.PointPosition.Y)); //draw facing left
                                    }
                                    else
                                    {
                                        fly.animator.DrawAnimation(SpriteEffects.FlipHorizontally, "tennisballdeath", new Vector2(fly.PointPosition.X, fly.PointPosition.Y)); //draw facing right

                                    }
                                    break;


                            }

                        }
                    }


                    foreach (MurderOrb m in murderOrbs)
                    {
                        m.Draw(spriteBatch);
                    }


                    if (SingleKeyPress(Keys.Space))
                    {
                        testCircle = player.AttackCircle;
                        testCircle.Draw(spriteBatch, attackImage);
                    }
                    #endregion
                    break;
                case GameState.GameOver:
                    spriteBatch.Draw(gameOverText, gameOverFill, Color.White);
                    spriteBatch.DrawString(gameText, string.Format("Score: {0}", scoreManager.Score), new Vector2(1820/2-50, 700), Color.Green);
                    break;
            }

            // TODO: Add your drawing code here
            spriteBatch.End();
            oldKBState = newKBState;
            base.Draw(gameTime);
        }
        #endregion

        #region Keyboard Methods
        /// <summary>
        /// Will get a single keypress of any key
        /// </summary>
        /// <param name="key">The key whose single keypress to get</param>
        /// <returns>Whether the key was pressed on this frame</returns>
        private bool SingleKeyPress(Keys key)
        {
            if (newKBState.IsKeyDown(key) && oldKBState.IsKeyUp(key))
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// Gets keyboard state
        /// </summary>
        private void CheckKeyboardInput()
        {
            newKBState = Keyboard.GetState();
        }
        #endregion

        public void ResetGame()
        {
            waveNumber = 0;
            enemyCount = 10;

            murderOrbs.Clear();

            player.alive = true;
            player.VectorPosition = Vector2.Zero;

            enemies = new Flies(null);
        }
    }
}
        
    



