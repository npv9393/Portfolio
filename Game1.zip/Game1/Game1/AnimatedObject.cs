﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
namespace Game1
{

    abstract class AnimatedObject
    {
        protected bool facingLeft;
        protected Animator objAnimator;

        public Animator animator { get { return objAnimator; } set { objAnimator = value; } }
        public bool FacingLeft { get { return facingLeft; } set { facingLeft = value; } }
        public abstract bool ObjectDirection (Rectangle objComparison);

    }
}
