﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/// <summary>
///
/// </summary> 


namespace Game1
{
    public partial class DataEditorForm : Form
    {
        // fields
        private double initialDeathOrb;
        private double addedDeathOrb;
        private double enemyNumber;
        private double playerSpeed;
        private double enemyScoreValue;
        private double enemySpeed;
        private double playerKnockback;
        private double enemyStun;
        private double enemiesAdded;
        private double deathOrbSpeed;
        private bool valueChange;
        private bool enterClicked;
        private double orbFrequency;
        BinaryWriter writer = null;
        Stream outStream;

        public DataEditorForm()
        {
            initialDeathOrb = 1;
            addedDeathOrb = 1;
            enemyNumber = 10;
            playerSpeed = 1;
            enemyScoreValue = 10;
            enemySpeed = 1;
            playerKnockback = 1;
            enemyStun = 1;
            enemiesAdded = 5;
            deathOrbSpeed = 1;
            valueChange = false;
            enterClicked = false;
            orbFrequency = 2;

            InitializeComponent();
        }

        /// <summary>
        /// Changes initial number of enemies
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void EnemyNumber_ValueChanged(object sender, EventArgs e)
        {
            if(EnemyNumber.Value <= EnemyNumber.Maximum && EnemyNumber.Value >= EnemyNumber.Minimum)
            {
                enemyNumber = (double)EnemyNumber.Value;
            }
            valueChange = true;

        }

        /// <summary>
        /// Changes damage player deals
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void EnemyScoreValue_ValueChanged(object sender, EventArgs e)
        {
            if (EnemyScoreValue.Value <= EnemyScoreValue.Maximum && EnemyScoreValue.Value >= EnemyScoreValue.Minimum)
            {
                enemyScoreValue = (double)EnemyScoreValue.Value;
            }
            valueChange = true;

        }

        /// <summary>
        /// Changes damage enemy deals
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void PlayerSpeed_ValueChanged(object sender, EventArgs e)
        {
            if (PlayerSpeed.Value <= PlayerSpeed.Maximum && PlayerSpeed.Value >= PlayerSpeed.Minimum)
            {
                playerSpeed = (double)PlayerSpeed.Value;
            }
            else
            {
                playerSpeed = 1;
            }
            valueChange = true;
        }

        /// <summary>
        /// changes enemy speed
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void EnemySpeed_ValueChanged(object sender, EventArgs e)
        {
            if (EnemySpeed.Value <= EnemySpeed.Maximum && EnemySpeed.Value >= EnemySpeed.Minimum)
            {
                enemySpeed = (double)EnemySpeed.Value;
            }
            else
            {
                enemySpeed = 1;
            }
            valueChange = true;
        }

        /// <summary>
        /// Changes the knockback an enemy deals
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void EnemyStun_ValueChanged(object sender, EventArgs e)
        {
            if (EnemyStun.Value <= EnemyStun.Maximum && EnemyStun.Value >= EnemyStun.Minimum)
            {
                enemyStun = (double)EnemyStun.Value;
            }
            valueChange = true;

        }

        /// <summary>
        /// Changes the knockback the player deals
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void PlayerKnockback_ValueChanged(object sender, EventArgs e)
        {
            if (PlayerKnockback.Value <= PlayerKnockback.Maximum && PlayerKnockback.Value >= PlayerKnockback.Minimum)
            {
                playerKnockback = (double)PlayerKnockback.Value;
            }
            valueChange = true;

        }

        /// <summary>
        /// Changes the rate the enemies shoot
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void EnemiesAdded_ValueChanged(object sender, EventArgs e)
        {
            if (EnemiesAdded.Value <= EnemiesAdded.Maximum && EnemiesAdded.Value >= EnemiesAdded.Minimum)
            {
                enemiesAdded = (double)EnemiesAdded.Value;
            }
            valueChange = true;

        }

        private void DeathOrbSpeed_ValueChanged(object sender, EventArgs e)
        {
            if (DeathOrbSpeed.Value <= DeathOrbSpeed.Maximum && DeathOrbSpeed.Value >= DeathOrbSpeed.Minimum)
            {
                deathOrbSpeed = (double)DeathOrbSpeed.Value;
            }
            valueChange = true;
        }

        private void OrbFrequency_ValueChanged(object sender, EventArgs e)
        {
            if (OrbFrequency.Value <= OrbFrequency.Maximum && OrbFrequency.Value >= OrbFrequency.Minimum)
            {
                orbFrequency = (double)OrbFrequency.Value;
            }
            valueChange = true;
        }

        private void Enter_Click(object sender, EventArgs e)
        {
            try
            {
                outStream = File.OpenWrite("StatEditor.data");
                if (valueChange== true)
                {
                    writer = new BinaryWriter(outStream);
                    writer.Write(initialDeathOrb);
                    writer.Write(addedDeathOrb);
                    writer.Write(enemyNumber);
                    writer.Write(playerSpeed);
                    writer.Write(enemyScoreValue);
                    writer.Write(enemySpeed);
                    writer.Write(playerKnockback);
                    writer.Write(enemyStun);
                    writer.Write(enemiesAdded);
                    writer.Write(deathOrbSpeed);
                    writer.Write(orbFrequency);
                    enterClicked = true;
                }
                this.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: "+ ex.Message);
            }
            finally
            {
                if(writer != null)
                {
                    writer.Close();
                    enterClicked = true;
                }
            }
        }

        // property for checking if enter was clicked
        public bool EnterClicked
        {
            get { return enterClicked; }
            set { enterClicked = value; }
        }

    }
}
