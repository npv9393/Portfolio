﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Game1
{
    /// <summary>
    /// An agent is a ballistic thing with "desires"
    /// Desires are vectors representing where the agent wants to go
    /// </summary>
    class Agent : BallisticThing
    {
        // DesiredDir is always normalized
        // That is, its length is always 1
        // It points to wherever the agent desires to go
        private Vector2 desiredDir;
        public Vector2 DesiredDir
        {
            get
            {
                float lenSquared = desiredDir.LengthSquared();
                if ((lenSquared < 1.001f && lenSquared > 0.99f) || lenSquared == 0)
                {
                    return desiredDir;
                }
                else
                {
                    return Vector2.Normalize(desiredDir);
                }
            }

            set
            {
                desiredDir = value;
            }
        }

        // Whether the agent is stunned
        // Stunned agents are unmoved by desires
        // Stunned enemies can deal no damage to the player
        // When a stunned agent stops moving, it stops being stunned
        public bool Stunned { get; set; }

        // How forcefully desires move the agent
        // Can be thought of as the agent's "speed" for many purposes
        protected float desireForce;

        public Agent(Point size, Vector2 vectP, Texture2D sprite, float fric, float desireFrc)
            : base  (size, vectP, sprite, fric)
        {
            desireForce = desireFrc;
            DesiredDir = Vector2.Zero;
            Stunned = false;
        }

        public override void Draw(SpriteBatch sb)
        {
            if (Sprite != null)
                sb.Draw(Sprite, DrawRect, !Stunned ? Color.White : Color.DarkGray);
        }

        /// <summary>
        /// Updates the position of the agent
        /// </summary>
        /// <param name="deltaTime">The amount of time since the last frame</param>
        public override void Update(float deltaTime)
        {
            // Stay unstunned if not stunned
            // Else, unstun once velocity hits zero
            if (Stunned)
            {
                Stunned = (velocity != Vector2.Zero);
            }

            // This check must be made because stunned status may have changed
            if (!Stunned)
            {
                AddForce(DesiredForces());
            }
            ApplyForces(deltaTime);
        }

        /// <summary>
        /// Gets the desired forces of the agent, that is,
        /// The desired direction times the power of desire
        /// </summary>
        /// <returns>The directional force of desire</returns>
        private Vector2 DesiredForces()
        {
            return DesiredDir*desireForce;
        }

        /// <summary>
        /// Returns a multiline string with information about the player
        /// </summary>
        /// <returns>A multiline string with information about the player</returns>
        public override string ToString()
        {
            return string.Format("CollisionRect: {0}\nvectPos: {1}\nDesiredDir: {2}\nVelocity: {3}", CollisionRect, VectorPosition, DesiredDir, velocity);
        }

        // gets the Agent's desire force
        public float DesireForceStat
        {
            get { return desireForce; }
            set { this.desireForce = value; }
        }
    }
}
