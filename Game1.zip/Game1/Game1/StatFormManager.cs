﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game1
{
    class StatFormManager
    {
        /// Will allow the game to read from the statEditior's textfile with the stat changes
        /// Should read and keep the stats from the file
        /// Will keep them in a dictionary

        // creating reader and dictoinary to return
        private BinaryReader reader = null;
        public Dictionary<string, float> stats;

        // fields for the ints to put into the dictionary
        private float initialDeathOrb;
        private float addedDeathOrb;
        private float enemyNumber;
        private float playerSpeed;
        private float enemyScoreValue; 
        private float enemySpeed;
        private float playerKnockback;
        private float enemyStun;
        private float enemiesAdded;
        private float deathOrbSpeed;
        private int orbFrequency;
        private Stream inStream;


        // construtor for the manager
        public StatFormManager()
        {
            stats = new Dictionary<string, float>();
        }

        // reading from the file and adding to the dictionary
        public void ReadFile()
        {
            try
            {
                // reading the values
                inStream = File.OpenRead("StatEditor.data");

                reader = new BinaryReader(inStream);

                initialDeathOrb = (float)(reader.ReadDouble());
                addedDeathOrb = (float)(reader.ReadDouble());
                enemyNumber = (float)(reader.ReadDouble());
                playerSpeed = (float)(reader.ReadDouble());
                enemyScoreValue = (float)(reader.ReadDouble());
                enemySpeed = (float)(reader.ReadDouble());
                playerKnockback = (float)(reader.ReadDouble());
                enemyStun = (float)(reader.ReadDouble());
                enemiesAdded = (float)(reader.ReadDouble());
                deathOrbSpeed = (float)(reader.ReadDouble());
                orbFrequency = (int)(reader.ReadDouble());

                //adding the stats to the dictionary

                stats.Add("initialDeathOrb", initialDeathOrb);
                stats.Add("addedDeathOrb", addedDeathOrb);
                stats.Add("enemyNumber", enemyNumber);
                stats.Add("playerSpeed", playerSpeed);
                stats.Add("enemyScoreValue", enemyScoreValue);
                stats.Add("enemySpeed", enemySpeed);
                stats.Add("playerKnockback", playerKnockback);
                stats.Add("enemyStun", enemyStun);
                stats.Add("enemiesAdded", enemiesAdded);
                stats.Add("deathOrbSpeed", deathOrbSpeed);
                stats.Add("orbFrequency", orbFrequency);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
            finally
            {
                if (reader != null)
                {
                    reader.Close();
                }
            }
        }

        // get properties for all of the stats

        public float InitialDeathOrb
        {
            get { return initialDeathOrb; }
        }
        public float AddedDeathOrb
        {
            get { return addedDeathOrb; }
        }
        public float EnemyNumber
        {
            get { return enemyNumber; }
        }
        public float PlayerSpeed
        {
            get { return playerSpeed; }
        }
        public float EnemyScoreValue
        {
            get { return enemyScoreValue; }
        }
        public float EnemySpeed
        {
            get { return enemySpeed; }
        }
        public float PlayerKnockback
        {
            get { return playerKnockback; }
        }
        public float EnemyStun
        {
            get { return enemyStun; }
        }
        public float EnemiesAdded
        {
            get { return enemiesAdded; }
        }
        public float DeathOrbSpeed
        {
            get { return deathOrbSpeed; }
        }
        public int OrbFrequency
        {
            get { return orbFrequency; }
        }
    }
}
